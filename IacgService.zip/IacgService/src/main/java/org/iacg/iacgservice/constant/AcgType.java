package org.iacg.iacgservice.constant;

public class AcgType {
    public static final int ANIME = 1;     // 动漫
    public static final int MANGA = 2;     // 漫画
    public static final int GALGAME = 3;   // Galgame
}
