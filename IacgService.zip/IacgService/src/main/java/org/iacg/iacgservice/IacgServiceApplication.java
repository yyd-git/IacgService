package org.iacg.iacgservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IacgServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(IacgServiceApplication.class, args);
    }

}
