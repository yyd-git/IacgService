package org.iacg.iacgservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IacgServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
